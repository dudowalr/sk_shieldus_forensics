무인기 주식회사 채용 사이트
============================

실행 방법
---------
1. 이 폴더 전체를 원하는 위치로 옮깁니다.
2. start.bat을 더블클릭합니다.
3. 브라우저에서 http://127.0.0.1:8080 이 열립니다.

PowerShell 또는 명령 프롬프트에서 실행하려면:

    python front.py

다른 포트를 사용하려면:

    python front.py --port 9000

구성
----
- front.py: Python 표준 라이브러리 기반 로컬 웹 서버
- front_site/index.html: 사이트 본문
- front_site/styles.css: 디자인과 반응형 스타일
- front_site/app.js: 채용공고 필터, 팝업, 이메일 복사 기능
- front_site/assets/: 로고와 히어로 이미지

정보
-----
채용 안내 버튼 혹은 밑에 직무 선택을 할 경우에도 이메일주소 팝업창이 뜸.