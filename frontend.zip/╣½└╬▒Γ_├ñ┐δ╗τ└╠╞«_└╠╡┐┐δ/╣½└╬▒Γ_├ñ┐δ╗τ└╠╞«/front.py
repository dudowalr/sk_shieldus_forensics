#!/usr/bin/env python3
"""무인기 주식회사 채용 사이트 로컬 개발 서버."""

from __future__ import annotations

import argparse
import os
import threading
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


ROOT = Path(__file__).resolve().parent / "front_site"


class DevHandler(SimpleHTTPRequestHandler):
    extensions_map = {
        **SimpleHTTPRequestHandler.extensions_map,
        ".html": "text/html; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".js": "application/javascript; charset=utf-8",
        ".svg": "image/svg+xml; charset=utf-8",
    }

    def end_headers(self) -> None:
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"[MUINGI] {self.address_string()} - {fmt % args}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="무인기 주식회사 채용 사이트 로컬 서버")
    parser.add_argument("--host", default="127.0.0.1", help="바인딩 호스트")
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("PORT", "8080")),
        help="로컬 포트 (기본값: 8080)",
    )
    parser.add_argument("--open", action="store_true", help="실행 후 브라우저 열기")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if not ROOT.is_dir():
        raise SystemExit(f"사이트 폴더가 없습니다: {ROOT}")

    os.chdir(ROOT)
    server = ThreadingHTTPServer((args.host, args.port), DevHandler)
    url = f"http://{args.host}:{args.port}"
    print("\n무인기 주식회사 Careers")
    print(f"  URL  : {url}")
    print(f"  ROOT : {ROOT}")
    print("  종료 : Ctrl+C\n")

    if args.open:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n서버를 종료합니다.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
