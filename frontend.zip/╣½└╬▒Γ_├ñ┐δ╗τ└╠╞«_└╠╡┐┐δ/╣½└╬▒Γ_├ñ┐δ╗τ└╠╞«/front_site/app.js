const RECRUIT_EMAIL = "muingi_recruit_2026@ingi.kr";

const header = document.querySelector("#site-header");
const menuButton = document.querySelector("#menu-button");
const mainNav = document.querySelector("#main-nav");
const roleSearch = document.querySelector("#role-search");
const filterButtons = [...document.querySelectorAll(".filter-chip")];
const roleCards = [...document.querySelectorAll(".role-card")];
const visibleCount = document.querySelector("#visible-count");
const noResults = document.querySelector("#no-results");
const modal = document.querySelector("#apply-modal");
const modalPanel = modal.querySelector(".apply-modal");
const modalClose = modal.querySelector(".modal-close");
const selectedRole = document.querySelector("#selected-role");
const subjectExample = document.querySelector("#subject-example");
const copyEmailButton = document.querySelector("#copy-email");
const openMailButton = document.querySelector("#open-mail");
const hideForDayButton = document.querySelector("#hide-for-day");
const toast = document.querySelector("#toast");

let activeFilter = "all";
let previousFocus = null;
let toastTimer = null;
const POPUP_HIDE_UNTIL_KEY = "muingi-recruit-hide-until";
const POPUP_SESSION_KEY = "muingi-recruit-popup-shown";
const ONE_DAY = 24 * 60 * 60 * 1000;

const setHeaderState = () => {
  header.classList.toggle("is-scrolled", window.scrollY > 24);
};

window.addEventListener("scroll", setHeaderState, { passive: true });
setHeaderState();

menuButton.addEventListener("click", () => {
  const isOpen = header.classList.toggle("menu-open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
  menuButton.setAttribute("aria-label", isOpen ? "메뉴 닫기" : "메뉴 열기");
});

mainNav.addEventListener("click", (event) => {
  if (event.target.closest("a")) {
    header.classList.remove("menu-open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "메뉴 열기");
  }
});

const updateRoles = () => {
  const query = roleSearch.value.trim().toLocaleLowerCase("ko");
  let count = 0;

  roleCards.forEach((card) => {
    const categoryMatch = activeFilter === "all" || card.dataset.category === activeFilter;
    const searchMatch = !query || card.dataset.search.toLocaleLowerCase("ko").includes(query);
    const isVisible = categoryMatch && searchMatch;
    card.hidden = !isVisible;
    if (isVisible) count += 1;
  });

  visibleCount.textContent = String(count);
  noResults.hidden = count !== 0;
};

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    activeFilter = button.dataset.filter;
    filterButtons.forEach((item) => item.classList.toggle("is-active", item === button));
    updateRoles();
  });
});

roleSearch.addEventListener("input", updateRoles);

const showToast = (message) => {
  toast.textContent = message;
  toast.classList.add("is-visible");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 2200);
};

const openApplyModal = (role = "지원 희망 포지션", { focus = true } = {}) => {
  previousFocus = document.activeElement;
  selectedRole.textContent = role;
  subjectExample.textContent =
    role === "지원 희망 포지션" ? "[지원 직무] 이름_지원" : `[${role}] 이름_지원`;
  modal.hidden = false;
  requestAnimationFrame(() => {
    modal.classList.add("is-visible");
    if (focus) modalClose.focus();
  });
};

const closeApplyModal = () => {
  modal.classList.remove("is-visible");
  window.setTimeout(() => {
    modal.hidden = true;
    if (previousFocus instanceof HTMLElement) previousFocus.focus();
  }, 250);
};

document.querySelectorAll(".open-apply").forEach((button) => {
  button.addEventListener("click", () => openApplyModal(button.dataset.role));
});

modalClose.addEventListener("click", closeApplyModal);

document.addEventListener("keydown", (event) => {
  if (modal.hidden) return;

  if (event.key === "Escape") {
    closeApplyModal();
  }
});

const copyEmail = async () => {
  try {
    await navigator.clipboard.writeText(RECRUIT_EMAIL);
  } catch {
    const helper = document.createElement("textarea");
    helper.value = RECRUIT_EMAIL;
    helper.setAttribute("readonly", "");
    helper.style.position = "fixed";
    helper.style.opacity = "0";
    document.body.appendChild(helper);
    helper.select();
    document.execCommand("copy");
    helper.remove();
  }
  showToast("이메일 주소를 복사했습니다.");
};

copyEmailButton.addEventListener("click", copyEmail);

openMailButton.addEventListener("click", () => {
  const role = selectedRole.textContent;
  const subject =
    role === "지원 희망 포지션" ? "[지원 직무] 이름_지원" : `[${role}] 이름_지원`;
  window.location.href = `mailto:${RECRUIT_EMAIL}?subject=${encodeURIComponent(subject)}`;
});

hideForDayButton.addEventListener("click", () => {
  try {
    localStorage.setItem(POPUP_HIDE_UNTIL_KEY, String(Date.now() + ONE_DAY));
  } catch {
    sessionStorage.setItem(POPUP_SESSION_KEY, "shown");
  }
  closeApplyModal();
  showToast("24시간 동안 채용 팝업을 표시하지 않습니다.");
});

document.querySelectorAll(".faq-item button").forEach((button) => {
  button.addEventListener("click", () => {
    const item = button.closest(".faq-item");
    const isOpen = item.classList.toggle("is-open");
    button.setAttribute("aria-expanded", String(isOpen));
  });
});

const revealObserver = new IntersectionObserver(
  (entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.12, rootMargin: "0px 0px -30px" },
);

document.querySelectorAll(".reveal").forEach((element) => revealObserver.observe(element));

const formatCounter = (value) => new Intl.NumberFormat("ko-KR").format(value);
const counterObserver = new IntersectionObserver(
  (entries, observer) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      const target = entry.target;
      const endValue = Number(target.dataset.counter);
      const duration = 1200;
      const started = performance.now();

      const tick = (now) => {
        const progress = Math.min((now - started) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        target.textContent = formatCounter(Math.round(endValue * eased));
        if (progress < 1) requestAnimationFrame(tick);
      };

      requestAnimationFrame(tick);
      observer.unobserve(target);
    });
  },
  { threshold: 0.75 },
);

document.querySelectorAll("[data-counter]").forEach((counter) => counterObserver.observe(counter));

document.querySelector("#year").textContent = String(new Date().getFullYear());

const shouldShowRecruitPopup = () => {
  try {
    const hideUntil = Number(localStorage.getItem(POPUP_HIDE_UNTIL_KEY) || 0);
    if (hideUntil > Date.now()) return false;
    if (hideUntil) localStorage.removeItem(POPUP_HIDE_UNTIL_KEY);
  } catch {
    // 저장소 접근이 제한된 경우에는 현재 세션에서만 중복 표시를 막는다.
  }
  return !sessionStorage.getItem(POPUP_SESSION_KEY);
};

window.setTimeout(() => {
  if (shouldShowRecruitPopup()) {
    sessionStorage.setItem(POPUP_SESSION_KEY, "shown");
    openApplyModal("지원 희망 포지션", { focus: false });
  }
}, 1200);
