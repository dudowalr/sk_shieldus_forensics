@echo off
setlocal
cd /d "%~dp0"

set "PORT=8080"
if not "%~1"=="" set "PORT=%~1"

where python > nul 2>&1
if not errorlevel 1 goto RUN_PYTHON

where py > nul 2>&1
if not errorlevel 1 goto RUN_PY

echo Python 3 was not found. Install Python 3 and try again.
pause
exit /b 1

:RUN_PYTHON
if /I "%~2"=="--no-open" goto RUN_PYTHON_NO_OPEN
python front.py --port %PORT% --open
goto END

:RUN_PYTHON_NO_OPEN
python front.py --port %PORT%
goto END

:RUN_PY
if /I "%~2"=="--no-open" goto RUN_PY_NO_OPEN
py -3 front.py --port %PORT% --open
goto END

:RUN_PY_NO_OPEN
py -3 front.py --port %PORT%

:END
endlocal
